<footer class="bg-dark text-light py-3">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <p>&copy; 2023 My Blog. All Rights Reserved.</p>
      </div>
      <div class="col-md-6">
        <ul class="list-inline float-md-right">
          <li class="list-inline-item"><a href="home.php">Home</a></li>
          <li class="list-inline-item"><a href="page.php">Blog</a></li>
          <li class="list-inline-item" data-bs-toggle="modal" data-bs-target="#contactModal"><a href="#">Contact</a></li>
          <li class="list-inline-item" data-bs-toggle="modal" data-bs-target="#feedbackModal"><a href="#">Feedback</a></li>
        </ul>
      </div>
    </div>
  </div>
</footer>



<!-- Modal Feedback -->
<div class="modal fade" id="feedbackModal" tabindex="-1" aria-labelledby="feedbackModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="feedbackModalLabel">Feedback Form</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="post">
          <?php 

            if(!isset($_SESSION['user_id'])){

          ?>
          <div class="mb-3">
            <label for="feedback-name" class="form-label">Name</label>
            <input type="text" class="form-control" name="name" id="feedback-name" required>
          </div>
          <div class="mb-3">
            <label for="feedback-email" class="form-label">Email</label>
            <input type="email" class="form-control" name="email" id="feedback-email" required>
          </div>

        <?php }else echo "<h3> Welcome User </h3>"  ?>


          <div class="mb-3">
            <label for="feedback-message" class="form-label">Message</label>
            <textarea class="form-control" name="message" id="feedback-message" rows="5" required></textarea>
          </div>
          <button type="submit" name="submit_feedback" class="btn btn-primary">Submit</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php 
if(isset($_POST['submit_feedback'])){
  extract($_POST);
  
  if(isset($_SESSION['user_id'])){
    $email=$_SESSION['email'];
    $name=$_SESSION['user_name'];
    $user_id=$_SESSION['user_id'];
    $query= "INSERT INTO user_feedback (user_id,user_name,user_email,feedback) VALUES ($user_id , '$name' , '$email' , '$message');";
  }
$query= "INSERT INTO user_feedback (user_name,user_email,feedback) VALUES ( '$name' , '$email' , '$message');";
$result=mysqli_query($connect , $query);
if($result){


              //Sending Email
                
                echo $subject="Feedback Received From $name";
                $message="$message";
                $send_from=$email;

                $query="SELECT email from user WHERE role_id=2";
                $result=mysqli_query($connect , $query);
                while($admin_email=mysqli_fetch_assoc($result)){
                $send_to=$admin_email['email'];
      
                include('php_mailer/email_proc.php');
  
                }
                
            //email done

  



}else echo "no";

}
?>

<!-- Modal Contact -->
<div class="modal fade" id="contactModal" tabindex="-1" aria-labelledby="contactModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="contactModalLabel">Contact Us</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form>
          <div class="mb-3">

            <table>
              <tr>
                <td>Call </td>
                <td> : </td>
                <td><a href="#">+923073023185</a></td>
              </tr>

              <tr>
                <td>Email</td>
                <td> : </td>
                <td><a href="#">yasirrajput185@gmail.com</a></td>
              </tr>

              <tr>
                <td>Address</td>
                <td> : </td>
                <td><a href="#">Hidaya Jamshoro</a></td>
              </tr>

            </table>
        </form>
      </div>
    </div>
  </div>
</div>


<script type="text/javascript" src="require/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>