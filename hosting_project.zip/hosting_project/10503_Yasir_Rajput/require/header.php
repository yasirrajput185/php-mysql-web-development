
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog App</title>
    <link rel="stylesheet" href="require/bootstrap/css/bootstrap.min.css">
</head>

<body style="background-color: beige">    



  <nav class="navbar navbar-expand-lg bg-dark">
    <div class="container-fluid">
     
      <a class="navbar-brand text-white fs-2" href="home.php"><h3><b>YR BLOGS</b></h3></a>
      <button style="color:white" class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon" style="color:white"></span>
      </button>


      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <a class="nav-link active text-white" aria-current="page" href="home.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="page.php">Pages</a>
          </li>
          <!-- <li class="nav-item">
            <a class="nav-link text-white" href="blog.php">Posts</a>
          </li> -->
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Category
            </a>
            <ul class="dropdown-menu">

              <?php 
include('database/connection.php');
$query = "SELECT * FROM category WHERE category_status='Active' "; 
$result = mysqli_query($connect, $query);

while ($categories = mysqli_fetch_assoc($result)) {

              ?>
              

              <li>
                <a class="dropdown-item" href="category_posts.php?category_title=<?php echo $categories['category_title']?>&category_id=<?php echo $categories['category_id']?>"> <?php echo $categories['category_title'] ?></a>
              </li>
        <?php } ?>

            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="Theme_setting.php">Theme</a>
          </li>
        </ul>
        <form action="home.php" class="d-flex">
          <input class="form-control me-2" type="search" name='search' placeholder="Search by Post Title" aria-label="Search" required>
          <button class="btn btn-outline-success text-white" type="submit">Search</button>
        </form>
        
        <ul class="navbar-nav ms-auto">
          <!-- if logged in show Logout.. if not logged in show login and register -->
          
          
          <?php
include('database/connection.php');

if (isset($_SESSION['user_id'])) {

$query = "SELECT * FROM user WHERE user_id = '".$_SESSION['user_id']."'";
$result = mysqli_query($connect, $query);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['user_image'] = $row['user_image'];
      }  


  ?>
<li class="nav-item dropdown">
  <a class="nav-link text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
    <div class="d-flex align-items-center position-relative">
      <?php echo $row['first_name']." ".$row['last_name']; ?>
      <div class="rounded-circle overflow-hidden" style="width: 50px; height: 50px;">
        <img src="images/dp/<?php echo $_SESSION['user_image'] ?>" alt="Profile Image" style="width: 100%; height: 100%; object-fit: cover;">
      </div>
      <span class="ms-2 dropdown-arrow"></span>
    </div>
  </a>
  <ul class="dropdown-menu dropdown-menu-end">
    <li><a class="dropdown-item" href="view_profile.php">View Profile</a></li>
    <li><a class="dropdown-item" href="edit_profile.php?user_image=<?php echo $_SESSION['user_image'] ?>">Edit Profile</a></li>
    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
  </ul>
</li>
    

<?php 
} else {
  ?>
    <li class="nav-item">
    <a class="nav-link text-white" href="login.php">Login</a>
    </li>
    <li class="nav-item">
            <a class="nav-link text-white" href="register.php">Register</a>
    </li>
<?php
  }
?>

        </ul>
      </div>
    </div>
  </nav>

