<div class="col-md-3 p-5">
<?php
include('database/connection.php');

if(isset($_SESSION['user_id'])){
$query = "SELECT role_id FROM user WHERE email = '".$_SESSION['email']."'";
$result = mysqli_query($connect, $query);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['role_id'] = $row['role_id'];
        if ($_SESSION['role_id'] == 2) {

    ?>
<style>
    a{
        text-decoration: none;
    }
</style>
            <div class="card" style="width: 18rem;">
                <table>
                    <tr>
                        <td><h3>Welcome Admin</h3></td>
                    </tr>
                    <tr>
                        <td><a href="manage_post.php">Manage Posts</a></td>
                    </tr>
                    <tr>
                        <td><a href="manage_post_attachments.php">Manage Post Attachments</a></td>
                    </tr>
                    <tr>
                        <td><a href="manage_comments.php">Manage Comments</a></td>
                    </tr>
                    <tr>
                        <td><a href="manage_user.php">Manage User</a></td>
                    </tr>
                    <tr>
                        <td><a href="manage_category.php">Manage Category</a></td>
                    </tr>
                    <tr>
                        <td><a href="manage_feedback.php">Manage Feedback</a></td>
                    </tr>
                    <tr>
                        <td><a href="register.php">Create User Account</a></td>
                    </tr>
                </table>
            </div>
        
    <?php
    }
    else echo "<h3>Welcome User</h3>";
}}
?>

<br><br>
            <h1>Recent Post</h1>
            

            <?php

            isset($_GET['blog_id'])?$blog_id=$_GET['blog_id']:"";

            if(isset($blog_id)){
                $query="SELECT * FROM post WHERE blog_id=$blog_id ORDER BY post_id DESC";
            }else{
                $query="SELECT * FROM post ORDER BY post_id DESC";
            }
            $count=0;
            $result = mysqli_query($connect, $query);
            while ($row = mysqli_fetch_assoc($result)) {
                if($count==5)break;
                $count++; 

            ?>

            <div class="card" style="width: 18rem; ">
                <img src="images/post/<?php echo $row['featured_image'] ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $row['post_title'] ?></h5>
                    <p class="card-text"><?php echo $row['post_summary'] ?></p>
                    <a href="single_post.php?post_id=<?php echo $row['post_id']?>" class="btn btn-primary ">Open Post</a>
                </div>
            </div>

            <br/><br/>   
                  <?php } ?>

<!--             <div class="card" style="width: 18rem;">
                <img src="images/international.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Post Name</h5>
                    <p class="card-text">Some quick example text to build on the Post Name and make up the bulk of the card's content.</p>
                    <a href="#" class="btn btn-primary ">Open Post</a>
                </div>
            </div>

            <br/><br/>

            <div class="card" style="width: 18rem;">
                <img src="images/pak.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Post Name</h5>
                    <p class="card-text">Some quick example text to build on the Post Name and make up the bulk of the card's content.</p>
                    <a href="#" class="btn btn-primary ">Open Post</a>
                </div>
            </div>

            <br/><br/> -->

        </div>