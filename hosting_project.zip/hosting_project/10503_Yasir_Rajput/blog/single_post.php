<?php 
include('require/header.php');
include('database/connection.php');
?>

<div class="container">
    <div class="row">
 

<?php 

$post_id=$_GET['post_id'];

  $query = "SELECT * FROM post WHERE post_id=$post_id"; // WHERE match category
  $result = mysqli_query($connect, $query);
  
//  print_r($row);
      while($row = mysqli_fetch_assoc($result)){
        $post_id=$row['post_id'];
 ?>
       <div class="col-md-9">
          <h1><?php echo $row['post_title']?></h1>
          <hr>

  <div class="col">
    <div class="card">
      <img src="images/post/<?php echo $row['featured_image']?>" class="card-img-top" alt="...">
      <div class="card-body">
        <h3 class="card-title fw-bold">Summary : <?php echo $row['post_summary']?></h3>
        <p class="card-text"><h5><h4><b>Description :</b></h4> <?php echo $row['post_description']?></h5>
        </p>
      </div>
    </div>
  </div>

  <br><br>
    <?php
    if(isset($_SESSION['user_id'])&& $row['is_comment_allowed']==1){
    ?>

    <div class="row">
      <form method="post">
        <div class="form-floating col-md-9">
          <textarea class="form
          -control" placeholder="Leave a comment here" id="floatingTextarea2" name="text_comment" style="height: 100px"></textarea>
          <label for="floatingTextarea2">Comments</label>
        </div>
        <div class="col-md-3">
          <button type="submit" name="post_comment<?php echo $post_id;?>" class="btn btn-primary text-white float-end">Post Comment</button>
        </div>
      </form>
    </div>

    <?php } ?>

  </div>
  <hr>

  <?php

  if(isset($_POST["post_comment$post_id"]) && $_POST["text_comment"]!=""){

    $text_comment=$_POST['text_comment'];
    $query = "INSERT INTO post_comment (post_id , user_id , comment) 
              VALUES ('$post_id' , '$user_id' , '$text_comment')";
    $result1 = mysqli_query($connect, $query);

    if ($result1) {
      echo "Commented Successfully..";

      // unset($_POST['post_comment']);
    } else {
      echo "Error ";
    }
  }

  $query = "SELECT c.comment, u.first_name, u.last_name,u.user_image
  FROM post_comment AS c
  JOIN user AS u ON c.user_id = u.user_id
  WHERE c.post_id = '" . $row['post_id'] . "' AND c.is_active = 'Active'";

  $result2 = mysqli_query($connect, $query);

  while($row = mysqli_fetch_assoc($result2)){
  ?>

    <!--show comment Div -->
    <div class="d-flex">
      <div class="rounded-circle overflow-hidden" style="width: 50px; height: 50px;">
        <img src="images/dp/<?php echo $row['user_image'] ?>" alt="Profile Image" style="width: 100%; height: 100%; object-fit: cover;"> 
      </div>
      <h4><b>&nbsp;
        <?php 
        echo $row['first_name']." ".$row['last_name'];
        ?>
      </b></h4>
    </div>
    <div class="card-header rounded bg-dark text-white m-2 p-1">
      <p><?php echo $row['comment']; ?></p>
    </div>
    <hr>
        
    <!-- End comment Div -->

  <?php
  }
echo "</div>";
  // blog_loop end
}
?>




<?php 
include('require/sidebar.php');
?>

</div>
</div>
<?php 
include('require/footer.php');
?>
