/*
SQLyog Ultimate v12.5.0 (64 bit)
MySQL - 10.4.27-MariaDB : Database - 10503_Yasir_Rajput
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`10503_Yasir_Rajput` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `10503_Yasir_Rajput`;

/*Table structure for table `blog` */

DROP TABLE IF EXISTS `blog`;

CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `blog_title` varchar(11) DEFAULT NULL,
  `post_per_page` int(11) DEFAULT NULL,
  `blog_background_image` text DEFAULT NULL,
  `blog_status` enum('Active','InActive') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`blog_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `blog_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `blog` */

insert  into `blog`(`blog_id`,`user_id`,`blog_title`,`post_per_page`,`blog_background_image`,`blog_status`,`created_at`,`updated_at`) values 
(2,2,'Greenistan',2,'admin.jpg','Active','2023-05-24 10:33:46',NULL),
(3,2,'Pakistan',4,'entertainment.jpg','Active','2023-05-24 10:33:54',NULL),
(4,2,'India',5,'international.jpg','Active','2023-05-24 10:34:03',NULL),
(5,2,'Football',5,'Screenshot 2023-03-20 000225.png','Active','2023-05-24 10:34:11',NULL),
(6,2,'Cricket',5,'pak.jpg','Active','2023-05-24 10:34:22',NULL),
(7,4,'News',5,'international.jpg','Active','2023-05-17 14:45:28',NULL),
(8,4,'Technology',5,'tech.jpg','Active','2023-05-17 14:44:56',NULL);

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_title` varchar(100) DEFAULT NULL,
  `category_description` text DEFAULT NULL,
  `category_status` enum('Active','InActive') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `unique_category_title` (`category_title`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `category` */

insert  into `category`(`category_id`,`category_title`,`category_description`,`category_status`,`created_at`,`updated_at`) values 
(2,'Sports','Cricket','Active','2023-05-23 17:01:30',NULL),
(3,'News','International','Active','2023-05-23 17:01:28',NULL),
(4,'Entertainment','Movies','Active','2023-05-22 12:48:59',NULL),
(5,'Games','Car Race','Active','2023-05-17 14:59:37',NULL),
(6,'Education','Scholorship','Active','2023-05-23 17:02:11',NULL);

/*Table structure for table `following_blog` */

DROP TABLE IF EXISTS `following_blog`;

CREATE TABLE `following_blog` (
  `follow_id` int(11) NOT NULL AUTO_INCREMENT,
  `follower_id` int(11) DEFAULT NULL,
  `blog_following_id` int(11) DEFAULT NULL,
  `status` enum('Followed','Unfollowed') DEFAULT 'Followed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`follow_id`),
  KEY `blog_following_id` (`blog_following_id`),
  KEY `follower_id` (`follower_id`),
  CONSTRAINT `following_blog_ibfk_1` FOREIGN KEY (`blog_following_id`) REFERENCES `blog` (`blog_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `following_blog_ibfk_2` FOREIGN KEY (`follower_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `following_blog` */

insert  into `following_blog`(`follow_id`,`follower_id`,`blog_following_id`,`status`,`created_at`,`updated_at`) values 
(3,2,7,'Unfollowed','2023-05-17 16:03:44',NULL),
(6,2,8,'Unfollowed','2023-05-23 12:58:04',NULL),
(7,1,3,'Unfollowed','2023-05-24 09:48:22',NULL);

/*Table structure for table `post` */

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) DEFAULT NULL,
  `post_title` varchar(200) NOT NULL,
  `post_summary` text NOT NULL,
  `post_description` longtext NOT NULL,
  `featured_image` text DEFAULT NULL,
  `post_status` enum('Active','InActive') DEFAULT 'Active',
  `is_comment_allowed` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`post_id`),
  KEY `blog_id` (`blog_id`),
  CONSTRAINT `post_ibfk_1` FOREIGN KEY (`blog_id`) REFERENCES `blog` (`blog_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post` */

insert  into `post`(`post_id`,`blog_id`,`post_title`,`post_summary`,`post_description`,`featured_image`,`post_status`,`is_comment_allowed`,`created_at`,`updated_at`) values 
(1,2,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','imranuno.jpg','Active',1,'2023-05-17 11:14:19','2023-05-24 10:06:18'),
(2,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','news.jpg','Active',1,'2023-05-17 09:23:55','2023-05-24 10:03:08'),
(3,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','health.jpg','Active',1,'2023-05-17 09:23:57','2023-05-24 10:02:01'),
(20,4,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','entertainment.jpg','Active',1,'2023-05-17 09:23:59','2023-05-24 10:02:01'),
(21,5,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','Screenshot 2023-03-20 004207.png','Active',1,'2023-05-15 16:25:15','2023-05-24 10:02:01'),
(22,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','Screenshot 2023-03-20 000909.png','Active',1,'2023-05-17 09:24:00','2023-05-24 10:02:01'),
(23,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','logo.png','Active',1,'2023-05-17 09:39:25','2023-05-24 10:02:01'),
(24,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','logo.png','Active',1,'2023-05-17 09:54:46','2023-05-24 10:02:01'),
(25,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','logo.png','Active',1,'2023-05-17 09:55:12','2023-05-24 10:02:01'),
(26,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','logo.png','Active',1,'2023-05-17 09:55:39','2023-05-24 10:02:01'),
(27,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','logo.png','Active',1,'2023-05-17 09:58:11','2023-05-24 10:02:01'),
(28,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','logo.png','Active',1,'2023-05-17 10:03:14','2023-05-24 10:02:01'),
(29,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','logo.png','Active',1,'2023-05-17 10:09:41','2023-05-24 10:02:01'),
(30,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-17 10:40:28','2023-05-24 10:02:01'),
(31,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','tech.jpg','Active',1,'2023-05-18 12:38:27','2023-05-24 10:02:01'),
(32,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','tech.jpg','Active',1,'2023-05-18 12:41:15','2023-05-24 10:02:01'),
(33,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','health.jpg','Active',1,'2023-05-18 12:41:47','2023-05-24 10:02:01'),
(34,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','health.jpg','Active',1,'2023-05-18 12:43:48','2023-05-24 10:02:01'),
(35,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','health.jpg','Active',1,'2023-05-18 12:44:05','2023-05-24 10:02:01'),
(36,5,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','news.jpg','Active',1,'2023-05-18 12:46:15','2023-05-24 10:02:01'),
(37,5,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','news.jpg','Active',1,'2023-05-18 12:46:52','2023-05-24 10:02:01'),
(38,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:22:34','2023-05-24 10:02:01'),
(39,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:24:20','2023-05-24 10:02:01'),
(40,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:26:08','2023-05-24 10:02:01'),
(41,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:31:47','2023-05-24 10:02:01'),
(42,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:35:46','2023-05-24 10:02:01'),
(43,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:36:32','2023-05-24 10:02:01'),
(44,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:39:21','2023-05-24 10:02:01'),
(45,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:39:27','2023-05-24 10:02:01'),
(46,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:40:14','2023-05-24 10:02:01'),
(47,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:40:37','2023-05-24 10:02:01'),
(48,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:41:13','2023-05-24 10:02:01'),
(49,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:41:23','2023-05-24 10:02:01'),
(50,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:42:18','2023-05-24 10:02:01'),
(51,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:42:50','2023-05-24 10:02:01'),
(52,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:43:58','2023-05-24 10:02:01'),
(53,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','pak.jpg','Active',1,'2023-05-22 10:50:00','2023-05-24 10:02:01'),
(54,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','tech.jpg','Active',1,'2023-05-23 10:55:47','2023-05-24 10:02:01'),
(55,6,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','tech.jpg','Active',1,'2023-05-22 10:53:31','2023-05-24 10:02:01'),
(56,3,'Dummy Post Title','Dummy Summary Lorem Ipsum is simply dummy text of the printing and typesetting industry. ','It is a long established fact that a reader will be distracted by the readable \r\ncontent of a page when looking at its layout. \r\nThe point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using making it look like \r\nreadable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for will \r\nuncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n','imranuno.jpg','Active',1,'2023-05-22 15:24:14','2023-05-24 10:02:01');

/*Table structure for table `post_attachment` */

DROP TABLE IF EXISTS `post_attachment`;

CREATE TABLE `post_attachment` (
  `post_attachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `post_attachment_title` varchar(200) DEFAULT NULL,
  `post_attachment_path` text DEFAULT NULL,
  `is_active` enum('Active','InActive') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`post_attachment_id`),
  KEY `fk1` (`post_id`),
  CONSTRAINT `fk1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_attachment` */

insert  into `post_attachment`(`post_attachment_id`,`post_id`,`post_attachment_title`,`post_attachment_path`,`is_active`,`created_at`,`updated_at`) values 
(1,40,'entertainment.jpg','images/post/attachment/1510517783_entertainment.jpg','InActive','2023-05-22 15:35:51','2023-05-23 12:07:56'),
(2,40,'imranuno.jpg','images/post/attachment/290651660_imranuno.jpg','Active','2023-05-22 15:35:51','2023-05-23 12:08:08'),
(3,40,'international.jpg','images/post/attachment/454935611_international.jpg','Active','2023-05-22 15:35:51',NULL),
(4,40,'news.jpg','images/post/attachment/1369778658_news.jpg','Active','2023-05-22 15:35:51',NULL),
(5,40,'pak.jpg','images/post/attachment/1975056373_pak.jpg','Active','2023-05-22 15:35:51',NULL),
(6,41,'entertainment.jpg','images/post/attachment/1242040683_entertainment.jpg','Active','2023-05-22 15:35:51',NULL),
(7,41,'imranuno.jpg','images/post/attachment/1302701133_imranuno.jpg','Active','2023-05-22 15:35:51',NULL),
(8,41,'international.jpg','images/post/attachment/701431910_international.jpg','Active','2023-05-22 15:35:51',NULL),
(9,41,'news.jpg','images/post/attachment/1470679786_news.jpg','Active','2023-05-22 15:35:51',NULL),
(10,41,'pak.jpg','images/post/attachment/1285994335_pak.jpg','Active','2023-05-22 15:35:51',NULL),
(11,42,'entertainment.jpg','images/post/attachment/1761287040_entertainment.jpg','Active','2023-05-22 15:35:51',NULL),
(12,42,'imranuno.jpg','images/post/attachment/357443259_imranuno.jpg','Active','2023-05-22 15:35:51',NULL),
(13,42,'international.jpg','images/post/attachment/237913648_international.jpg','Active','2023-05-22 15:35:51',NULL),
(14,42,'news.jpg','images/post/attachment/210998888_news.jpg','Active','2023-05-22 15:35:51',NULL),
(15,42,'pak.jpg','images/post/attachment/364339606_pak.jpg','Active','2023-05-22 15:35:51',NULL),
(16,43,'entertainment.jpg','images/post/attachment/1919869972_entertainment.jpg','Active','2023-05-22 15:35:51',NULL),
(17,43,'imranuno.jpg','images/post/attachment/1346630216_imranuno.jpg','Active','2023-05-22 15:35:51',NULL),
(18,43,'international.jpg','images/post/attachment/1695574114_international.jpg','Active','2023-05-22 15:35:51',NULL),
(19,43,'news.jpg','images/post/attachment/103457969_news.jpg','Active','2023-05-22 15:35:51',NULL),
(20,43,'pak.jpg','images/post/attachment/1649309148_pak.jpg','Active','2023-05-22 15:35:51',NULL),
(21,44,'entertainment.jpg','images/post/attachment/2101292172_entertainment.jpg','Active','2023-05-22 15:35:51',NULL),
(22,44,'imranuno.jpg','images/post/attachment/610589793_imranuno.jpg','Active','2023-05-22 15:35:51',NULL),
(23,44,'international.jpg','images/post/attachment/2082461708_international.jpg','Active','2023-05-22 15:35:51',NULL),
(24,44,'news.jpg','images/post/attachment/1643640624_news.jpg','Active','2023-05-22 15:35:51',NULL),
(25,44,'pak.jpg','images/post/attachment/1904203498_pak.jpg','Active','2023-05-22 15:35:51',NULL),
(26,45,'entertainment.jpg','images/post/attachment/404255246_entertainment.jpg','Active','2023-05-22 15:35:51',NULL),
(27,45,'imranuno.jpg','images/post/attachment/251190728_imranuno.jpg','Active','2023-05-22 15:35:51',NULL),
(28,45,'international.jpg','images/post/attachment/492435723_international.jpg','Active','2023-05-22 15:35:51',NULL),
(29,45,'news.jpg','images/post/attachment/612630948_news.jpg','Active','2023-05-22 15:35:51',NULL),
(30,45,'pak.jpg','images/post/attachment/133891315_pak.jpg','Active','2023-05-22 15:35:51',NULL),
(31,46,'entertainment.jpg','images/post/attachment/75295130_entertainment.jpg','Active','2023-05-22 15:35:51',NULL),
(32,46,'imranuno.jpg','images/post/attachment/237996179_imranuno.jpg','Active','2023-05-22 15:35:51',NULL),
(33,46,'international.jpg','images/post/attachment/523786060_international.jpg','Active','2023-05-22 15:35:51',NULL),
(34,46,'news.jpg','images/post/attachment/2085776580_news.jpg','Active','2023-05-22 15:35:51',NULL),
(35,46,'pak.jpg','images/post/attachment/871188458_pak.jpg','Active','2023-05-22 15:35:51',NULL),
(36,47,'entertainment.jpg','images/post/attachment/295956893_entertainment.jpg','Active','2023-05-22 15:35:51',NULL),
(37,47,'imranuno.jpg','images/post/attachment/1432567102_imranuno.jpg','Active','2023-05-22 15:35:51',NULL),
(38,47,'international.jpg','images/post/attachment/2057328912_international.jpg','Active','2023-05-22 15:35:51',NULL),
(39,47,'news.jpg','images/post/attachment/1773468102_news.jpg','Active','2023-05-22 15:35:51',NULL),
(40,47,'pak.jpg','images/post/attachment/1138516190_pak.jpg','Active','2023-05-22 15:35:51',NULL),
(41,48,'entertainment.jpg','images/post/attachment/1753153057_entertainment.jpg','Active','2023-05-22 15:35:51',NULL),
(42,48,'imranuno.jpg','images/post/attachment/292940200_imranuno.jpg','Active','2023-05-22 15:35:51',NULL),
(43,48,'international.jpg','images/post/attachment/2071584178_international.jpg','Active','2023-05-22 15:35:51',NULL),
(44,48,'news.jpg','images/post/attachment/1627034392_news.jpg','Active','2023-05-22 15:35:51',NULL),
(45,48,'pak.jpg','images/post/attachment/1738259835_pak.jpg','Active','2023-05-22 15:35:51',NULL),
(46,49,'entertainment.jpg','images/post/attachment/1344505671_entertainment.jpg','Active','2023-05-22 15:35:51',NULL),
(47,49,'imranuno.jpg','images/post/attachment/526771094_imranuno.jpg','Active','2023-05-22 15:35:51',NULL),
(48,49,'international.jpg','images/post/attachment/25392694_international.jpg','Active','2023-05-22 15:35:51',NULL),
(49,49,'news.jpg','images/post/attachment/2056101326_news.jpg','Active','2023-05-22 15:35:51',NULL),
(50,49,'pak.jpg','images/post/attachment/20370379_pak.jpg','Active','2023-05-22 15:35:51',NULL),
(51,50,'entertainment.jpg','images/post/attachment/98846232_entertainment.jpg','Active','2023-05-22 15:35:51',NULL),
(52,50,'imranuno.jpg','images/post/attachment/365043551_imranuno.jpg','Active','2023-05-22 15:35:51',NULL),
(53,50,'international.jpg','images/post/attachment/1777422697_international.jpg','Active','2023-05-22 15:35:51',NULL),
(54,50,'news.jpg','images/post/attachment/1044607404_news.jpg','Active','2023-05-22 15:35:51',NULL),
(55,50,'pak.jpg','images/post/attachment/306900706_pak.jpg','Active','2023-05-22 15:35:51',NULL),
(56,51,'entertainment.jpg','images/post/attachment/1362477124_entertainment.jpg','Active','2023-05-22 15:35:51',NULL),
(57,51,'imranuno.jpg','images/post/attachment/1804015202_imranuno.jpg','Active','2023-05-22 15:35:51',NULL),
(58,51,'international.jpg','images/post/attachment/721583037_international.jpg','Active','2023-05-22 15:35:51',NULL),
(59,51,'news.jpg','images/post/attachment/1959792200_news.jpg','Active','2023-05-22 15:35:51',NULL),
(60,51,'pak.jpg','images/post/attachment/729571603_pak.jpg','Active','2023-05-22 15:35:51',NULL),
(61,52,'entertainment.jpg','images/post/attachment/1453246703_entertainment.jpg','Active','2023-05-22 15:35:51',NULL),
(62,52,'imranuno.jpg','images/post/attachment/1149315736_imranuno.jpg','Active','2023-05-22 15:35:51',NULL),
(63,52,'international.jpg','images/post/attachment/1693755949_international.jpg','Active','2023-05-22 15:35:51',NULL),
(64,52,'news.jpg','images/post/attachment/1778838188_news.jpg','Active','2023-05-22 15:35:51',NULL),
(65,52,'pak.jpg','images/post/attachment/1088518686_pak.jpg','Active','2023-05-22 15:35:51',NULL),
(66,53,'entertainment.jpg','images/post/attachment/77466818_entertainment.jpg','Active','2023-05-22 15:35:51',NULL),
(67,53,'imranuno.jpg','images/post/attachment/1620172129_imranuno.jpg','InActive','2023-05-22 15:35:51','2023-05-24 10:31:53'),
(68,53,'international.jpg','images/post/attachment/2147038835_international.jpg','InActive','2023-05-22 15:35:51','2023-05-24 10:31:57'),
(69,53,'news.jpg','images/post/attachment/1677064741_news.jpg','Active','2023-05-22 15:35:51',NULL),
(70,53,'pak.jpg','images/post/attachment/2000868576_pak.jpg','Active','2023-05-22 15:35:51',NULL),
(71,54,'entertainment.jpg','images/post/attachment/773255971_entertainment.jpg','InActive','2023-05-22 15:35:51','2023-05-22 16:14:17'),
(72,54,'imranuno.jpg','images/post/attachment/1900083099_imranuno.jpg','InActive','2023-05-22 15:35:51','2023-05-22 16:14:36'),
(73,54,'international.jpg','images/post/attachment/1853503403_international.jpg','InActive','2023-05-22 15:35:51','2023-05-22 16:14:23'),
(74,54,'news.jpg','images/post/attachment/1437829392_news.jpg','InActive','2023-05-22 15:35:51','2023-05-23 11:00:34'),
(75,54,'pak.jpg','images/post/attachment/1735284264_pak.jpg','InActive','2023-05-22 15:35:51','2023-05-22 16:14:27'),
(76,55,'tech.jpg','images/post/attachment/2081571101_tech.jpg','InActive','2023-05-22 15:34:45','2023-05-22 15:50:05'),
(77,56,'entertainment.jpg','images/post/attachment/1439961282_entertainment.jpg','Active','2023-05-22 15:35:51',NULL),
(78,56,'health.jpg','images/post/attachment/2089574839_health.jpg','Active','2023-05-22 15:35:51',NULL),
(79,56,'pak.jpg','images/post/attachment/235933761_pak.jpg','Active','2023-05-22 15:35:51',NULL),
(80,56,'tech.jpg','images/post/attachment/1430446791_tech.jpg','Active','2023-05-22 15:35:51',NULL),
(81,54,'international.jpg','images/post/attachment/182633720_international.jpg','InActive','2023-05-23 11:02:04','2023-05-23 11:02:12'),
(82,54,'news.jpg','images/post/attachment/1577386570_news.jpg','InActive','2023-05-23 11:02:05','2023-05-23 11:16:30'),
(83,54,'pak.jpg','images/post/attachment/1800235257_pak.jpg','InActive','2023-05-23 11:02:05','2023-05-23 11:17:24'),
(84,54,'blog.php','images/post/attachment/490530026_blog.php','InActive','2023-05-23 11:11:07','2023-05-23 11:16:24'),
(85,54,'Database (Day-3).pptx','images/post/attachment/423619490_Database (Day-3).pptx','Active','2023-05-23 11:15:15',NULL);

/*Table structure for table `post_category` */

DROP TABLE IF EXISTS `post_category`;

CREATE TABLE `post_category` (
  `post_category_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`post_category_id`),
  KEY `post_id` (`post_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `post_category_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_category_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_category` */

insert  into `post_category`(`post_category_id`,`post_id`,`category_id`,`created_at`,`updated_at`) values 
(5,26,5,'2023-05-17 09:55:39',NULL),
(6,27,2,'2023-05-17 09:58:11',NULL),
(7,28,2,'2023-05-17 10:03:14',NULL),
(8,29,2,'2023-05-17 10:09:41',NULL),
(9,30,2,'2023-05-17 10:40:29',NULL),
(10,38,2,'2023-05-22 10:22:34',NULL),
(11,38,3,'2023-05-22 10:22:34',NULL),
(12,38,4,'2023-05-22 10:22:34',NULL),
(13,38,5,'2023-05-22 10:22:34',NULL),
(14,39,2,'2023-05-22 10:24:20',NULL),
(15,39,3,'2023-05-22 10:24:20',NULL),
(16,39,4,'2023-05-22 10:24:20',NULL),
(17,39,5,'2023-05-22 10:24:20',NULL),
(18,40,2,'2023-05-22 10:26:08',NULL),
(19,40,3,'2023-05-22 10:26:08',NULL),
(20,40,4,'2023-05-22 10:26:08',NULL),
(21,40,5,'2023-05-22 10:26:08',NULL),
(22,41,2,'2023-05-22 10:31:47',NULL),
(23,41,3,'2023-05-22 10:31:47',NULL),
(24,41,4,'2023-05-22 10:31:47',NULL),
(25,41,5,'2023-05-22 10:31:47',NULL),
(26,42,2,'2023-05-22 10:35:46',NULL),
(27,42,3,'2023-05-22 10:35:46',NULL),
(28,42,4,'2023-05-22 10:35:46',NULL),
(29,42,5,'2023-05-22 10:35:46',NULL),
(30,43,2,'2023-05-22 10:36:32',NULL),
(31,43,3,'2023-05-22 10:36:32',NULL),
(32,43,4,'2023-05-22 10:36:32',NULL),
(33,43,5,'2023-05-22 10:36:32',NULL),
(34,44,2,'2023-05-22 10:39:21',NULL),
(35,44,3,'2023-05-22 10:39:21',NULL),
(36,44,4,'2023-05-22 10:39:21',NULL),
(37,44,5,'2023-05-22 10:39:22',NULL),
(38,45,2,'2023-05-22 10:39:27',NULL),
(39,45,3,'2023-05-22 10:39:27',NULL),
(40,45,4,'2023-05-22 10:39:27',NULL),
(41,45,5,'2023-05-22 10:39:27',NULL),
(42,46,2,'2023-05-22 10:40:14',NULL),
(43,46,3,'2023-05-22 10:40:14',NULL),
(44,46,4,'2023-05-22 10:40:15',NULL),
(45,46,5,'2023-05-22 10:40:15',NULL),
(46,47,2,'2023-05-22 10:40:37',NULL),
(47,47,3,'2023-05-22 10:40:37',NULL),
(48,47,4,'2023-05-22 10:40:37',NULL),
(49,47,5,'2023-05-22 10:40:37',NULL),
(50,48,2,'2023-05-22 10:41:13',NULL),
(51,48,3,'2023-05-22 10:41:13',NULL),
(52,48,4,'2023-05-22 10:41:13',NULL),
(53,48,5,'2023-05-22 10:41:13',NULL),
(54,49,2,'2023-05-22 10:41:23',NULL),
(55,49,3,'2023-05-22 10:41:23',NULL),
(56,49,4,'2023-05-22 10:41:23',NULL),
(57,49,5,'2023-05-22 10:41:23',NULL),
(58,50,2,'2023-05-22 10:42:19',NULL),
(59,50,3,'2023-05-22 10:42:19',NULL),
(60,50,4,'2023-05-22 10:42:19',NULL),
(61,50,5,'2023-05-22 10:42:19',NULL),
(62,51,2,'2023-05-22 10:42:50',NULL),
(63,51,3,'2023-05-22 10:42:50',NULL),
(64,51,4,'2023-05-22 10:42:50',NULL),
(65,51,5,'2023-05-22 10:42:50',NULL),
(66,52,2,'2023-05-22 10:43:58',NULL),
(67,52,3,'2023-05-22 10:43:58',NULL),
(68,52,4,'2023-05-22 10:43:58',NULL),
(69,52,5,'2023-05-22 10:43:58',NULL),
(70,53,2,'2023-05-22 10:50:00',NULL),
(71,53,3,'2023-05-22 10:50:00',NULL),
(72,53,4,'2023-05-22 10:50:00',NULL),
(73,53,5,'2023-05-22 10:50:00',NULL),
(78,55,3,'2023-05-22 10:53:31',NULL),
(79,56,2,'2023-05-22 13:09:02',NULL),
(80,56,3,'2023-05-22 13:09:02',NULL),
(81,56,4,'2023-05-22 13:09:03',NULL),
(82,56,5,'2023-05-22 13:09:03',NULL),
(90,54,3,'2023-05-23 10:55:10',NULL),
(91,54,4,'2023-05-23 10:55:10',NULL),
(92,54,5,'2023-05-23 10:55:10',NULL),
(98,1,6,'2023-05-23 17:05:41',NULL);

/*Table structure for table `post_comment` */

DROP TABLE IF EXISTS `post_comment`;

CREATE TABLE `post_comment` (
  `post_comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_active` enum('Active','InActive') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`post_comment_id`),
  KEY `user_id` (`user_id`),
  KEY `post_id` (`post_id`),
  CONSTRAINT `post_comment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `post_comment_ibfk_2` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post_comment` */

insert  into `post_comment`(`post_comment_id`,`post_id`,`user_id`,`comment`,`is_active`,`created_at`) values 
(1,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','InActive','2023-05-24 10:05:46'),
(2,2,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','InActive','2023-05-24 10:05:46'),
(3,2,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','InActive','2023-05-24 10:05:46'),
(4,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','InActive','2023-05-24 10:05:46'),
(10,20,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','InActive','2023-05-24 10:05:46'),
(12,3,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(13,3,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(14,3,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(15,3,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(16,30,4,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(17,21,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(18,21,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(19,21,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(20,37,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(21,36,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(23,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(24,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(25,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(26,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(27,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(28,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(29,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(30,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(31,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(32,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(33,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(34,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(35,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(36,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(37,1,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(38,51,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(39,51,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(40,20,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(41,20,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(42,20,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(43,37,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(44,37,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(45,37,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(46,37,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(47,37,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(48,37,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(49,37,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(50,37,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(51,37,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(52,37,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(53,37,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(54,37,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(55,37,2,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(56,33,1,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46'),
(57,33,1,'This is a Comment.  If you use this site regularly and would like to help keep the site on the Internet, please consider donating a small sum to help pay for the hosting and bandwidth bill.','Active','2023-05-24 10:05:46');

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_type` varchar(50) NOT NULL,
  `is_active` enum('Active','InActive') DEFAULT 'Active',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `role` */

insert  into `role`(`role_id`,`role_type`,`is_active`) values 
(1,'user','Active'),
(2,'admin','Active');

/*Table structure for table `setting` */

DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `setting_key` varchar(100) DEFAULT NULL,
  `setting_value` varchar(100) DEFAULT NULL,
  `setting_status` enum('Active','InActive') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`setting_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `setting_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `setting` */

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT 1,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` text NOT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `user_image` text DEFAULT NULL,
  `address` text DEFAULT NULL,
  `is_approved` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `is_active` enum('Active','InActive') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `unique_email` (`email`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user` */

insert  into `user`(`user_id`,`role_id`,`first_name`,`last_name`,`email`,`password`,`gender`,`date_of_birth`,`user_image`,`address`,`is_approved`,`is_active`,`created_at`,`updated_at`) values 
(1,1,'Imran','Khan Niazi','user@gmail.com','12345','Male','2023-05-11','blog-3.jpg','Jamshoro','Approved','Active','2023-05-24 10:28:01',NULL),
(2,2,'Yasir Rao','Rajput','admin@gmail.com','12345','Male','2023-05-11','blog-3.jpg','Jamshoro','Approved','Active','2023-05-24 10:28:48',NULL),
(4,2,'yasir','rajput','yasir@gmail.com','12345','Male','2023-05-14','user.jpg','Jamshoro','Pending','Active','2023-05-22 12:51:48',NULL),
(5,1,'yasir','tahir','yasirtahir@gmail.com','12345','Male','2023-05-22','carousel-3.jpg','jamshoro hidaya','Rejected','InActive','2023-05-18 14:52:54',NULL),
(6,1,'Admin','creating account','ac@gmail.com','12345','Male','2023-05-17','blog-3.jpg','jamshoro hidaya','Approved','Active','2023-05-18 14:50:13',NULL),
(7,1,'yasir','tahir','ysir@gmail.com','aaaaaaaa','Male','2023-05-19','entertainment.jpg','asdasdadada','Approved','Active','2023-05-18 14:53:11',NULL),
(8,1,'new account by ','Admin','yasirhist@gmail.com','yasir185','Male','2322-02-07','entertainment.jpg','jamshoro hidaya','Approved','Active','2023-05-24 10:30:43',NULL);

/*Table structure for table `user_feedback` */

DROP TABLE IF EXISTS `user_feedback`;

CREATE TABLE `user_feedback` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`feedback_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `user_feedback` */

insert  into `user_feedback`(`feedback_id`,`user_id`,`user_name`,`user_email`,`feedback`,`created_at`,`updated_at`) values 
(1,2,'Yasir Rajput','admin@gmail.com','yasir','2023-05-18 15:55:48',NULL),
(2,1,'visitor','visitor@gmail.com','how can i join you','2023-05-18 15:59:41',NULL),
(3,NULL,'visitor','visitor@gmail.com','how can i join you','2023-05-18 16:01:00',NULL),
(4,NULL,'visitor 2','yasir@a','aaaaaaaaa','2023-05-18 16:01:20',NULL),
(5,NULL,'visitor 2','yasir@a','aaaaaaaaa','2023-05-18 16:09:43',NULL),
(6,NULL,'visitor 2','yasir@a','aaaaaaaaa','2023-05-18 16:10:17',NULL),
(7,NULL,'visitor 2','yasir@a','aaaaaaaaa','2023-05-18 16:12:48',NULL),
(8,NULL,'visitor 2','yasir@a','aaaaaaaaa','2023-05-18 16:12:55',NULL),
(9,NULL,'visitor 2','yasir@a','aaaaaaaaa','2023-05-18 16:15:32',NULL),
(10,NULL,'visitor 2','yasir@a','aaaaaaaaa','2023-05-18 16:25:11',NULL),
(11,NULL,'aa','ashanlakyari@gmail.com','aaa','2023-05-18 16:33:34',NULL),
(12,NULL,'aaa','ashanlakyari@gmail.com','aaaaaaaa','2023-05-18 16:47:51',NULL),
(13,NULL,'Yasir Rajput','admin@gmail.com','yasir','2023-05-22 09:40:30',NULL),
(14,NULL,'Yasir Rajput','admin@gmail.com','ssssss','2023-05-22 09:42:40',NULL),
(15,NULL,'Yasir Rajput','admin@gmail.com','ssssssssssss','2023-05-22 09:43:49',NULL),
(16,NULL,'Yasir Rajput','admin@gmail.com','ssssssssssss','2023-05-22 09:44:36',NULL),
(17,NULL,'Yasir Rajput','admin@gmail.com','aaaaaaa','2023-05-22 09:47:20',NULL),
(18,NULL,'Yasir Rajput','admin@gmail.com','ysir','2023-05-22 11:15:31',NULL),
(19,NULL,'Yasir Rajput','admin@gmail.com','this is feedback','2023-05-22 16:17:45',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
