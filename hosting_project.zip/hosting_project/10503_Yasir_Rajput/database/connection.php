<?php
if(!isset($_SESSION)){
    session_start();

}
$connect=mysqli_connect('localhost','root','','10503_yasir_rajput');
?>
