<?php 

include('database/connection.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
//use PHPMailer\Exception;

require ('php_mailer/PHPMailer/src/PHPMailer.php');
require ('php_mailer/PHPMailer/src/SMTP.php');
//require 'PHPMailer/src/Exception.php';


	// if($_FILES['file']['name']!=""){
 //            $file = $_FILES['file']['tmp_name'];
 //            $file_name = $_FILES['file']['name'];
 //            $target_dir = "attachment/";
 //            $target_file = $target_dir.$file_name;
 //            move_uploaded_file($file, $target_file);
	// 	}

        

		//Create a new PHPMailer instance
		$mail = new PHPMailer();
		//Tell PHPMailer to use SMTP
		$mail->isSMTP();

		//Enable SMTP debugging
		// SMTP::DEBUG_OFF = off (for production use)
		// SMTP::DEBUG_CLIENT = client messages
		// SMTP::DEBUG_SERVER = client and server messages
		// $mail->SMTPDebug = SMTP::DEBUG_SERVER;
		//Set the hostname of the mail server
		$mail->Host = 'smtp.gmail.com';
		// use
		// $mail->Host = gethostbyname('smtp.gmail.com');
		// if your network does not support SMTP over IPv6
		//Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
		$mail->Port = 587;
		//Set the encryption mechanism to use - STARTTLS or SMTPS
		$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
		//Whether to use SMTP authentication
		$mail->SMTPAuth = true;
		//Username to use for SMTP authentication - use full email address for gmail
		$mail->Username = 'hostingyasir@gmail.com';
		//Password to use for SMTP authentication
		$mail->Password = 'rcufjoowilnvmniz';
		
		//Set who the message is to be sent from
		$mail->setFrom($send_from);
		// //Set an alternative reply-to address
		
		//Set who the message is to be sent to
		$mail->addAddress($send_to);

		//Set the subject line
		
        $mail->Subject = $subject;
		
		//Read an HTML message body
		$mail->msgHTML("$message");
		//Attach an image file (optional)
		if(isset($target_file)){
		$mail->addAttachment($target_file);
		}
		//send the message, check for errors
		if($mail->send()){
			$msg ="Email Send Succesfully";
//		    header("location: index.php?msg=$msg&color=green");
        }else{
			$msg ="Email Send Failed: ".$mail->ErrorInfo;
//		    header("location: index.php?msg=$msg.&color=red");
		}		
	

	// else{
	// 	$msg = "Please Write Correct Email/Mesasge/From Filed";
	// 	header("location: index.php?msg=$msg.&color=red");
	// }
?>